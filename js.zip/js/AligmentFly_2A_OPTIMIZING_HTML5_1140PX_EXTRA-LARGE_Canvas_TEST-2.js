(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_", frames: [[0,0,1000,1000],[0,1002,1000,1000],[1002,0,1000,1000],[1002,1002,1000,1000]]}
];


// symbols:



(lib.DUCKFLY2 = function() {
	this.initialize(ss["AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.DUCKFLY3 = function() {
	this.initialize(ss["AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.DUCKFLY7 = function() {
	this.initialize(ss["AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.DUCKFLY8 = function() {
	this.initialize(ss["AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Tween51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY2();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY2();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY7();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY7();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY3();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY3();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY7();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY7();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY2();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY2();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.Tween41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DUCKFLY8();
	this.instance.parent = this;
	this.instance.setTransform(-500,-500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-500,1000,1000);


(lib.DUCK4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DUCK_FLY_6_png
	this.instance = new lib.Tween46("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(231).to({_off:false},0).to({startPosition:0},5).wait(1));

	// DUCK_FLY_2_png
	this.instance_1 = new lib.Tween44("synched",0);
	this.instance_1.parent = this;
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween46("synched",0);
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},226).to({state:[{t:this.instance_2}]},5).to({state:[]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(226).to({_off:false},0).to({_off:true},5).wait(6));

	// DUCK_FLY_8_png
	this.instance_3 = new lib.Tween42("synched",0);
	this.instance_3.parent = this;
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween44("synched",0);
	this.instance_4.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},221).to({state:[{t:this.instance_4}]},5).to({state:[]},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(221).to({_off:false},0).to({_off:true},5).wait(11));

	// DUCK_FLY_6_png
	this.instance_5 = new lib.Tween51("synched",0);
	this.instance_5.parent = this;
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween41("synched",0);
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},215).to({state:[{t:this.instance_6}]},5).to({state:[]},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(215).to({_off:false},0).to({_off:true},5).wait(17));

	// DUCK_FLY_2_png
	this.instance_7 = new lib.Tween49("synched",0);
	this.instance_7.parent = this;
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween50("synched",0);
	this.instance_8.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},210).to({state:[{t:this.instance_8}]},5).to({state:[]},1).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(210).to({_off:false},0).to({_off:true},5).wait(22));

	// DUCK_FLY_8_png
	this.instance_9 = new lib.Tween48("synched",0);
	this.instance_9.parent = this;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(205).to({_off:false},0).to({startPosition:0},5).to({_off:true},1).wait(26));

	// DUCK_FLY_2_png_copy
	this.instance_10 = new lib.Tween45("synched",0);
	this.instance_10.parent = this;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(55).to({_off:false},0).to({y:-22.85},30).to({y:6.95},30).to({y:-6.15},30).to({y:-24.45},30).to({y:0},30).to({_off:true},1).wait(31));

	// DUCK_FLY_6_png
	this.instance_11 = new lib.Tween43("synched",0);
	this.instance_11.parent = this;
	this.instance_11._off = true;

	this.instance_12 = new lib.Tween45("synched",0);
	this.instance_12.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_11}]},50).to({state:[{t:this.instance_12}]},5).to({state:[]},1).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(50).to({_off:false},0).to({_off:true},5).wait(182));

	// DUCK_FLY_3_png
	this.instance_13 = new lib.Tween41("synched",0);
	this.instance_13.parent = this;
	this.instance_13._off = true;

	this.instance_14 = new lib.Tween43("synched",0);
	this.instance_14.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_13}]},45).to({state:[{t:this.instance_14}]},5).to({state:[]},1).wait(186));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(45).to({_off:false},0).to({_off:true},5).wait(187));

	// DUCK_FLY_2_png
	this.instance_15 = new lib.Tween43("synched",0);
	this.instance_15.parent = this;
	this.instance_15._off = true;

	this.instance_16 = new lib.Tween41("synched",0);
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_15}]},40).to({state:[{t:this.instance_16}]},5).to({state:[]},1).wait(191));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(40).to({_off:false},0).to({_off:true},5).wait(192));

	// DUCK_FLY_6_png
	this.instance_17 = new lib.Tween45("synched",0);
	this.instance_17.parent = this;
	this.instance_17._off = true;

	this.instance_18 = new lib.Tween43("synched",0);
	this.instance_18.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},35).to({state:[{t:this.instance_18}]},5).to({state:[]},1).wait(196));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(35).to({_off:false},0).to({_off:true},5).wait(197));

	// DUCK_FLY_3_png
	this.instance_19 = new lib.Tween47("synched",0);
	this.instance_19.parent = this;
	this.instance_19._off = true;

	this.instance_20 = new lib.Tween48("synched",0);
	this.instance_20.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19}]},30).to({state:[{t:this.instance_20}]},5).to({state:[]},1).wait(201));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(30).to({_off:false},0).to({_off:true},5).wait(202));

	// DUCK_FLY_6_png
	this.instance_21 = new lib.Tween45("synched",0);
	this.instance_21.parent = this;
	this.instance_21._off = true;

	this.instance_22 = new lib.Tween46("synched",0);
	this.instance_22.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21}]},25).to({state:[{t:this.instance_22}]},5).to({state:[]},1).wait(206));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(25).to({_off:false},0).to({_off:true},5).wait(207));

	// DUCK_FLY_2_png
	this.instance_23 = new lib.Tween43("synched",0);
	this.instance_23.parent = this;
	this.instance_23._off = true;

	this.instance_24 = new lib.Tween44("synched",0);
	this.instance_24.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_23}]},20).to({state:[{t:this.instance_24}]},5).to({state:[]},1).wait(211));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(20).to({_off:false},0).to({_off:true},5).wait(212));

	// DUCK_FLY_8_png
	this.instance_25 = new lib.Tween41("synched",0);
	this.instance_25.parent = this;
	this.instance_25._off = true;

	this.instance_26 = new lib.Tween42("synched",0);
	this.instance_26.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_25}]},15).to({state:[{t:this.instance_26}]},5).to({state:[]},1).wait(216));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(15).to({_off:false},0).to({_off:true},5).wait(217));

	// DUCK_FLY_2_png_copy
	this.instance_27 = new lib.Tween51("synched",0);
	this.instance_27.parent = this;
	this.instance_27._off = true;

	this.instance_28 = new lib.Tween41("synched",0);
	this.instance_28.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_27}]},10).to({state:[{t:this.instance_28}]},5).to({state:[]},1).wait(221));
	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(10).to({_off:false},0).to({_off:true},5).wait(222));

	// DUCK_FLY_6_png
	this.instance_29 = new lib.Tween49("synched",0);
	this.instance_29.parent = this;
	this.instance_29._off = true;

	this.instance_30 = new lib.Tween50("synched",0);
	this.instance_30.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_29}]},5).to({state:[{t:this.instance_30}]},5).to({state:[]},1).wait(226));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(5).to({_off:false},0).to({_off:true},5).wait(227));

	// DUCK_FLY_3_png
	this.instance_31 = new lib.Tween47("synched",0);
	this.instance_31.parent = this;

	this.instance_32 = new lib.Tween48("synched",0);
	this.instance_32.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31}]}).to({state:[{t:this.instance_32}]},5).to({state:[]},1).wait(231));
	this.timeline.addTween(cjs.Tween.get(this.instance_31).to({_off:true},5).wait(232));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-524.4,1000,1031.4);


(lib.DUCK3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DUCK_FLY_8_png
	this.instance = new lib.Tween42("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.instance_1 = new lib.Tween48("synched",0);
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},230).to({state:[{t:this.instance_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({_off:true},5).wait(1));

	// DUCK_FLY_2_png
	this.instance_2 = new lib.Tween41("synched",0);
	this.instance_2.parent = this;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween42("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},225).to({state:[{t:this.instance_3}]},5).to({state:[]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(225).to({_off:false},0).to({_off:true},5).wait(6));

	// DUCK_FLY_13
	this.instance_4 = new lib.Tween51("synched",0);
	this.instance_4.parent = this;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween41("synched",0);
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},220).to({state:[{t:this.instance_5}]},5).to({state:[]},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(220).to({_off:false},0).to({_off:true},5).wait(11));

	// DUCK_FLY_8
	this.instance_6 = new lib.Tween49("synched",0);
	this.instance_6.parent = this;
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween50("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},215).to({state:[{t:this.instance_7}]},5).to({state:[]},1).wait(15));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(215).to({_off:false},0).to({_off:true},5).wait(16));

	// DUCK_FLY_2_13
	this.instance_8 = new lib.Tween48("synched",0);
	this.instance_8.parent = this;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(210).to({_off:false},0).to({startPosition:0},5).to({_off:true},1).wait(20));

	// DUCK_FLY_7
	this.instance_9 = new lib.Tween45("synched",0);
	this.instance_9.parent = this;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(60).to({_off:false},0).to({y:-23},30).to({y:6.9},30).to({y:-6.05},30).to({y:-24.45},30).to({y:0},30).to({_off:true},1).wait(25));

	// DUCK_FLY_12
	this.instance_10 = new lib.Tween43("synched",0);
	this.instance_10.parent = this;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween45("synched",0);
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},55).to({state:[{t:this.instance_11}]},5).to({state:[]},1).wait(175));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(55).to({_off:false},0).to({_off:true},5).wait(176));

	// DUCK_FLY_7
	this.instance_12 = new lib.Tween41("synched",0);
	this.instance_12.parent = this;
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween43("synched",0);
	this.instance_13.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},50).to({state:[{t:this.instance_13}]},5).to({state:[]},1).wait(180));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(50).to({_off:false},0).to({_off:true},5).wait(181));

	// DUCK_FLY_2_png
	this.instance_14 = new lib.Tween43("synched",0);
	this.instance_14.parent = this;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween41("synched",0);
	this.instance_15.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},45).to({state:[{t:this.instance_15}]},5).to({state:[]},1).wait(185));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(45).to({_off:false},0).to({_off:true},5).wait(186));

	// DUCK_FLY_6_png
	this.instance_16 = new lib.Tween45("synched",0);
	this.instance_16.parent = this;
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween43("synched",0);
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},40).to({state:[{t:this.instance_17}]},5).to({state:[]},1).wait(190));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(40).to({_off:false},0).to({_off:true},5).wait(191));

	// DUCK_FLY_3_png
	this.instance_18 = new lib.Tween47("synched",0);
	this.instance_18.parent = this;
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween48("synched",0);
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},35).to({state:[{t:this.instance_19}]},5).to({state:[]},1).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(35).to({_off:false},0).to({_off:true},5).wait(196));

	// DUCK_FLY_6_png
	this.instance_20 = new lib.Tween45("synched",0);
	this.instance_20.parent = this;
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween46("synched",0);
	this.instance_21.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},30).to({state:[{t:this.instance_21}]},5).to({state:[]},1).wait(200));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(30).to({_off:false},0).to({_off:true},5).wait(201));

	// DUCK_FLY_2_png
	this.instance_22 = new lib.Tween43("synched",0);
	this.instance_22.parent = this;
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween44("synched",0);
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},25).to({state:[{t:this.instance_23}]},5).to({state:[]},1).wait(205));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(25).to({_off:false},0).to({_off:true},5).wait(206));

	// DUCK_FLY_8_png
	this.instance_24 = new lib.Tween41("synched",0);
	this.instance_24.parent = this;
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween42("synched",0);
	this.instance_25.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_24}]},20).to({state:[{t:this.instance_25}]},5).to({state:[]},1).wait(210));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(20).to({_off:false},0).to({_off:true},5).wait(211));

	// DUCK_FLY_2_png_copy
	this.instance_26 = new lib.Tween51("synched",0);
	this.instance_26.parent = this;
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween41("synched",0);
	this.instance_27.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},15).to({state:[{t:this.instance_27}]},5).to({state:[]},1).wait(215));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(15).to({_off:false},0).to({_off:true},5).wait(216));

	// DUCK_FLY_6_png
	this.instance_28 = new lib.Tween49("synched",0);
	this.instance_28.parent = this;
	this.instance_28._off = true;

	this.instance_29 = new lib.Tween50("synched",0);
	this.instance_29.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28}]},10).to({state:[{t:this.instance_29}]},5).to({state:[]},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(10).to({_off:false},0).to({_off:true},5).wait(221));

	// DUCK_FLY_3_png
	this.instance_30 = new lib.Tween47("synched",0);
	this.instance_30.parent = this;
	this.instance_30._off = true;

	this.instance_31 = new lib.Tween48("synched",0);
	this.instance_31.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30}]},5).to({state:[{t:this.instance_31}]},5).to({state:[]},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(5).to({_off:false},0).to({_off:true},5).wait(226));

	// DUCK_FLY_6_png
	this.instance_32 = new lib.Tween45("synched",0);
	this.instance_32.parent = this;

	this.instance_33 = new lib.Tween46("synched",0);
	this.instance_33.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).to({state:[{t:this.instance_33}]},5).to({state:[]},1).wait(230));
	this.timeline.addTween(cjs.Tween.get(this.instance_32).to({_off:true},5).wait(231));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-524.4,1000,1031.3);


(lib.DUCK2_OPTIMIZED = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DUCK_FLY_8_png
	this.instance = new lib.Tween41("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.instance_1 = new lib.Tween42("synched",0);
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},231).to({state:[{t:this.instance_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(231).to({_off:false},0).to({_off:true},5).wait(1));

	// DUCK_FLY_8_png
	this.instance_2 = new lib.Tween51("synched",0);
	this.instance_2.parent = this;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween41("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},225).to({state:[{t:this.instance_3}]},5).to({state:[]},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(225).to({_off:false},0).to({_off:true},5).wait(7));

	// DUCK_FLY_2_png_copy
	this.instance_4 = new lib.Tween49("synched",0);
	this.instance_4.parent = this;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween50("synched",0);
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},220).to({state:[{t:this.instance_5}]},5).to({state:[]},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(220).to({_off:false},0).to({_off:true},5).wait(12));

	// DUCK_FLY_6_png
	this.instance_6 = new lib.Tween48("synched",0);
	this.instance_6.parent = this;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(215).to({_off:false},0).to({startPosition:0},5).to({_off:true},1).wait(16));

	// DUCK_FLY_3_png
	this.instance_7 = new lib.Tween45("synched",0);
	this.instance_7.parent = this;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(65).to({_off:false},0).to({y:-22.9},30).to({y:7.05},30).to({y:-6.1},30).to({y:-24.55},30).to({y:0},30).to({_off:true},1).wait(21));

	// DUCK_FLY_6_png
	this.instance_8 = new lib.Tween43("synched",0);
	this.instance_8.parent = this;
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween45("synched",0);
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},60).to({state:[{t:this.instance_9}]},5).to({state:[]},1).wait(171));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(60).to({_off:false},0).to({_off:true},5).wait(172));

	// DUCK_FLY_2_png
	this.instance_10 = new lib.Tween41("synched",0);
	this.instance_10.parent = this;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween43("synched",0);
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},55).to({state:[{t:this.instance_11}]},5).to({state:[]},1).wait(176));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(55).to({_off:false},0).to({_off:true},5).wait(177));

	// DUCK_FLY_2_png
	this.instance_12 = new lib.Tween43("synched",0);
	this.instance_12.parent = this;
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween41("synched",0);
	this.instance_13.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},50).to({state:[{t:this.instance_13}]},5).to({state:[]},1).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(50).to({_off:false},0).to({_off:true},5).wait(182));

	// DUCK_FLY_6_png
	this.instance_14 = new lib.Tween45("synched",0);
	this.instance_14.parent = this;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween43("synched",0);
	this.instance_15.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},45).to({state:[{t:this.instance_15}]},5).to({state:[]},1).wait(186));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(45).to({_off:false},0).to({_off:true},5).wait(187));

	// DUCK_FLY_3_png
	this.instance_16 = new lib.Tween47("synched",0);
	this.instance_16.parent = this;
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween48("synched",0);
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},40).to({state:[{t:this.instance_17}]},5).to({state:[]},1).wait(191));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(40).to({_off:false},0).to({_off:true},5).wait(192));

	// DUCK_FLY_6_png
	this.instance_18 = new lib.Tween45("synched",0);
	this.instance_18.parent = this;
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween46("synched",0);
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},35).to({state:[{t:this.instance_19}]},5).to({state:[]},1).wait(196));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(35).to({_off:false},0).to({_off:true},5).wait(197));

	// DUCK_FLY_2_png
	this.instance_20 = new lib.Tween43("synched",0);
	this.instance_20.parent = this;
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween44("synched",0);
	this.instance_21.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},30).to({state:[{t:this.instance_21}]},5).to({state:[]},1).wait(201));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(30).to({_off:false},0).to({_off:true},5).wait(202));

	// DUCK_FLY_8_png
	this.instance_22 = new lib.Tween41("synched",0);
	this.instance_22.parent = this;
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween42("synched",0);
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},25).to({state:[{t:this.instance_23}]},5).to({state:[]},1).wait(206));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(25).to({_off:false},0).to({_off:true},5).wait(207));

	// DUCK_FLY_2_png_copy
	this.instance_24 = new lib.Tween51("synched",0);
	this.instance_24.parent = this;
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween41("synched",0);
	this.instance_25.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_24}]},20).to({state:[{t:this.instance_25}]},5).to({state:[]},1).wait(211));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(20).to({_off:false},0).to({_off:true},5).wait(212));

	// DUCK_FLY_6_png
	this.instance_26 = new lib.Tween49("synched",0);
	this.instance_26.parent = this;
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween50("synched",0);
	this.instance_27.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},15).to({state:[{t:this.instance_27}]},5).to({state:[]},1).wait(216));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(15).to({_off:false},0).to({_off:true},5).wait(217));

	// DUCK_FLY_3_png
	this.instance_28 = new lib.Tween47("synched",0);
	this.instance_28.parent = this;
	this.instance_28._off = true;

	this.instance_29 = new lib.Tween48("synched",0);
	this.instance_29.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28}]},10).to({state:[{t:this.instance_29}]},5).to({state:[]},1).wait(221));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(10).to({_off:false},0).to({_off:true},5).wait(222));

	// DUCK_FLY_6_png
	this.instance_30 = new lib.Tween45("synched",0);
	this.instance_30.parent = this;
	this.instance_30._off = true;

	this.instance_31 = new lib.Tween46("synched",0);
	this.instance_31.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30}]},5).to({state:[{t:this.instance_31}]},5).to({state:[]},1).wait(226));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(5).to({_off:false},0).to({_off:true},5).wait(227));

	// DUCK_FLY_2_png
	this.instance_32 = new lib.Tween43("synched",0);
	this.instance_32.parent = this;

	this.instance_33 = new lib.Tween44("synched",0);
	this.instance_33.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).to({state:[{t:this.instance_33}]},5).to({state:[]},1).wait(231));
	this.timeline.addTween(cjs.Tween.get(this.instance_32).to({_off:true},5).wait(232));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-524.5,1000,1031.6);


(lib.DUCK2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DUCK_FLY_8_png
	this.instance = new lib.Tween51("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.instance_1 = new lib.Tween41("synched",0);
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},230).to({state:[{t:this.instance_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({_off:true},5).wait(1));

	// DUCK_FLY_2_png_copy
	this.instance_2 = new lib.Tween49("synched",0);
	this.instance_2.parent = this;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween50("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},225).to({state:[{t:this.instance_3}]},5).to({state:[]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(225).to({_off:false},0).to({_off:true},5).wait(6));

	// DUCK_FLY_6_png
	this.instance_4 = new lib.Tween48("synched",0);
	this.instance_4.parent = this;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(220).to({_off:false},0).to({startPosition:0},5).to({_off:true},1).wait(10));

	// DUCK_FLY_3_png
	this.instance_5 = new lib.Tween45("synched",0);
	this.instance_5.parent = this;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(65).to({_off:false},0).to({y:-22.95},30).to({y:6.95},30).to({y:-6.15},30).to({y:-24.35},30).to({y:0},35).to({_off:true},1).wait(15));

	// DUCK_FLY_6_png
	this.instance_6 = new lib.Tween43("synched",0);
	this.instance_6.parent = this;
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween45("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},60).to({state:[{t:this.instance_7}]},5).to({state:[]},1).wait(170));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(60).to({_off:false},0).to({_off:true},5).wait(171));

	// DUCK_FLY_2_png
	this.instance_8 = new lib.Tween41("synched",0);
	this.instance_8.parent = this;
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween43("synched",0);
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},55).to({state:[{t:this.instance_9}]},5).to({state:[]},1).wait(175));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(55).to({_off:false},0).to({_off:true},5).wait(176));

	// DUCK_FLY_2_png
	this.instance_10 = new lib.Tween43("synched",0);
	this.instance_10.parent = this;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween41("synched",0);
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},50).to({state:[{t:this.instance_11}]},5).to({state:[]},1).wait(180));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(50).to({_off:false},0).to({_off:true},5).wait(181));

	// DUCK_FLY_6_png
	this.instance_12 = new lib.Tween45("synched",0);
	this.instance_12.parent = this;
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween43("synched",0);
	this.instance_13.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},45).to({state:[{t:this.instance_13}]},5).to({state:[]},1).wait(185));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(45).to({_off:false},0).to({_off:true},5).wait(186));

	// DUCK_FLY_3_png
	this.instance_14 = new lib.Tween47("synched",0);
	this.instance_14.parent = this;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween48("synched",0);
	this.instance_15.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},40).to({state:[{t:this.instance_15}]},5).to({state:[]},1).wait(190));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(40).to({_off:false},0).to({_off:true},5).wait(191));

	// DUCK_FLY_6_png
	this.instance_16 = new lib.Tween45("synched",0);
	this.instance_16.parent = this;
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween46("synched",0);
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},35).to({state:[{t:this.instance_17}]},5).to({state:[]},1).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(35).to({_off:false},0).to({_off:true},5).wait(196));

	// DUCK_FLY_2_png
	this.instance_18 = new lib.Tween43("synched",0);
	this.instance_18.parent = this;
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween44("synched",0);
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},30).to({state:[{t:this.instance_19}]},5).to({state:[]},1).wait(200));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(30).to({_off:false},0).to({_off:true},5).wait(201));

	// DUCK_FLY_8_png
	this.instance_20 = new lib.Tween41("synched",0);
	this.instance_20.parent = this;
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween42("synched",0);
	this.instance_21.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},25).to({state:[{t:this.instance_21}]},5).to({state:[]},1).wait(205));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(25).to({_off:false},0).to({_off:true},5).wait(206));

	// DUCK_FLY_2_png_copy
	this.instance_22 = new lib.Tween51("synched",0);
	this.instance_22.parent = this;
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween41("synched",0);
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},20).to({state:[{t:this.instance_23}]},5).to({state:[]},1).wait(210));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(20).to({_off:false},0).to({_off:true},5).wait(211));

	// DUCK_FLY_6_png
	this.instance_24 = new lib.Tween49("synched",0);
	this.instance_24.parent = this;
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween50("synched",0);
	this.instance_25.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_24}]},15).to({state:[{t:this.instance_25}]},5).to({state:[]},1).wait(215));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(15).to({_off:false},0).to({_off:true},5).wait(216));

	// DUCK_FLY_3_png
	this.instance_26 = new lib.Tween47("synched",0);
	this.instance_26.parent = this;
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween48("synched",0);
	this.instance_27.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},10).to({state:[{t:this.instance_27}]},5).to({state:[]},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(10).to({_off:false},0).to({_off:true},5).wait(221));

	// DUCK_FLY_6_png
	this.instance_28 = new lib.Tween45("synched",0);
	this.instance_28.parent = this;
	this.instance_28._off = true;

	this.instance_29 = new lib.Tween46("synched",0);
	this.instance_29.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28}]},5).to({state:[{t:this.instance_29}]},5).to({state:[]},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(5).to({_off:false},0).to({_off:true},5).wait(226));

	// DUCK_FLY_2_png
	this.instance_30 = new lib.Tween43("synched",0);
	this.instance_30.parent = this;

	this.instance_31 = new lib.Tween44("synched",0);
	this.instance_31.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_30}]}).to({state:[{t:this.instance_31}]},5).to({state:[]},1).wait(230));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).to({_off:true},5).wait(231));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-524.3,1000,1031.3);


(lib.DUCK1OPTIMIZED = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DUCK_FLY_2_png_copy
	this.instance = new lib.Tween51("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.instance_1 = new lib.Tween41("synched",0);
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},230).to({state:[{t:this.instance_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({_off:true},5).wait(1));

	// DUCK_FLY_6_png
	this.instance_2 = new lib.Tween49("synched",0);
	this.instance_2.parent = this;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween50("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},225).to({state:[{t:this.instance_3}]},5).to({state:[]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(225).to({_off:false},0).to({_off:true},5).wait(6));

	// DUCK_FLY_3_png
	this.instance_4 = new lib.Tween48("synched",0);
	this.instance_4.parent = this;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(220).to({_off:false},0).to({startPosition:0},5).to({_off:true},1).wait(10));

	// DUCK_FLY_6_png_copy
	this.instance_5 = new lib.Tween45("synched",0);
	this.instance_5.parent = this;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(70).to({_off:false},0).to({y:-23.05},30).to({y:7.05},30).to({y:-6.2},30).to({y:-24.45},30).to({y:0},30).to({_off:true},1).wait(15));

	// DUCK_FLY_2_png_copy
	this.instance_6 = new lib.Tween43("synched",0);
	this.instance_6.parent = this;
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween45("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},65).to({state:[{t:this.instance_7}]},5).to({state:[]},1).wait(165));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(65).to({_off:false},0).to({_off:true},5).wait(166));

	// DUCK_FLY_8_png
	this.instance_8 = new lib.Tween41("synched",0);
	this.instance_8.parent = this;
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween43("synched",0);
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},60).to({state:[{t:this.instance_9}]},5).to({state:[]},1).wait(170));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(60).to({_off:false},0).to({_off:true},5).wait(171));

	// DUCK_FLY_2_png
	this.instance_10 = new lib.Tween43("synched",0);
	this.instance_10.parent = this;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween41("synched",0);
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},55).to({state:[{t:this.instance_11}]},5).to({state:[]},1).wait(175));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(55).to({_off:false},0).to({_off:true},5).wait(176));

	// DUCK_FLY_6_png
	this.instance_12 = new lib.Tween45("synched",0);
	this.instance_12.parent = this;
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween43("synched",0);
	this.instance_13.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},50).to({state:[{t:this.instance_13}]},5).to({state:[]},1).wait(180));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(50).to({_off:false},0).to({_off:true},5).wait(181));

	// DUCK_FLY_3_png
	this.instance_14 = new lib.Tween47("synched",0);
	this.instance_14.parent = this;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween48("synched",0);
	this.instance_15.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},45).to({state:[{t:this.instance_15}]},5).to({state:[]},1).wait(185));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(45).to({_off:false},0).to({_off:true},5).wait(186));

	// DUCK_FLY_6_png
	this.instance_16 = new lib.Tween45("synched",0);
	this.instance_16.parent = this;
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween46("synched",0);
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},40).to({state:[{t:this.instance_17}]},5).to({state:[]},1).wait(190));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(40).to({_off:false},0).to({_off:true},5).wait(191));

	// DUCK_FLY_2_png
	this.instance_18 = new lib.Tween43("synched",0);
	this.instance_18.parent = this;
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween44("synched",0);
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},35).to({state:[{t:this.instance_19}]},5).to({state:[]},1).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(35).to({_off:false},0).to({_off:true},5).wait(196));

	// DUCK_FLY_8_png
	this.instance_20 = new lib.Tween41("synched",0);
	this.instance_20.parent = this;
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween42("synched",0);
	this.instance_21.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},30).to({state:[{t:this.instance_21}]},5).to({state:[]},1).wait(200));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(30).to({_off:false},0).to({_off:true},5).wait(201));

	// DUCK_FLY_2_png_copy
	this.instance_22 = new lib.Tween51("synched",0);
	this.instance_22.parent = this;
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween41("synched",0);
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},25).to({state:[{t:this.instance_23}]},5).to({state:[]},1).wait(205));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(25).to({_off:false},0).to({_off:true},5).wait(206));

	// DUCK_FLY_6_png
	this.instance_24 = new lib.Tween49("synched",0);
	this.instance_24.parent = this;
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween50("synched",0);
	this.instance_25.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_24}]},20).to({state:[{t:this.instance_25}]},5).to({state:[]},1).wait(210));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(20).to({_off:false},0).to({_off:true},5).wait(211));

	// DUCK_FLY_3_png
	this.instance_26 = new lib.Tween47("synched",0);
	this.instance_26.parent = this;
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween48("synched",0);
	this.instance_27.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},15).to({state:[{t:this.instance_27}]},5).to({state:[]},1).wait(215));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(15).to({_off:false},0).to({_off:true},5).wait(216));

	// DUCK_FLY_6_png
	this.instance_28 = new lib.Tween45("synched",0);
	this.instance_28.parent = this;
	this.instance_28._off = true;

	this.instance_29 = new lib.Tween46("synched",0);
	this.instance_29.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28}]},10).to({state:[{t:this.instance_29}]},5).to({state:[]},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(10).to({_off:false},0).to({_off:true},5).wait(221));

	// DUCK_FLY_2_png
	this.instance_30 = new lib.Tween43("synched",0);
	this.instance_30.parent = this;
	this.instance_30._off = true;

	this.instance_31 = new lib.Tween44("synched",0);
	this.instance_31.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30}]},5).to({state:[{t:this.instance_31}]},5).to({state:[]},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(5).to({_off:false},0).to({_off:true},5).wait(226));

	// DUCK_FLY_8_png
	this.instance_32 = new lib.Tween41("synched",0);
	this.instance_32.parent = this;

	this.instance_33 = new lib.Tween42("synched",0);
	this.instance_33.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).to({state:[{t:this.instance_33}]},5).to({state:[]},1).wait(230));
	this.timeline.addTween(cjs.Tween.get(this.instance_32).to({_off:true},5).wait(231));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-524.4,1000,1031.5);


(lib.DUCK1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DUCK_FLY_2_png_copy
	this.instance = new lib.Tween51("synched",0);
	this.instance.parent = this;
	this.instance._off = true;

	this.instance_1 = new lib.Tween41("synched",0);
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},230).to({state:[{t:this.instance_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({_off:true},5).wait(1));

	// DUCK_FLY_6_png
	this.instance_2 = new lib.Tween49("synched",0);
	this.instance_2.parent = this;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween50("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},225).to({state:[{t:this.instance_3}]},5).to({state:[]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(225).to({_off:false},0).to({_off:true},5).wait(6));

	// DUCK_FLY_3_png
	this.instance_4 = new lib.Tween48("synched",0);
	this.instance_4.parent = this;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(220).to({_off:false},0).to({startPosition:0},5).to({_off:true},1).wait(10));

	// DUCK_FLY_6_png
	this.instance_5 = new lib.Tween45("synched",0);
	this.instance_5.parent = this;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(70).to({_off:false},0).to({y:-23},30).to({y:6.9},30).to({y:-6.25},30).to({y:-24.35},30).to({y:0},30).to({_off:true},1).wait(15));

	// DUCK_FLY_2_png
	this.instance_6 = new lib.Tween43("synched",0);
	this.instance_6.parent = this;
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween45("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},65).to({state:[{t:this.instance_7}]},5).to({state:[]},1).wait(165));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(65).to({_off:false},0).to({_off:true},5).wait(166));

	// DUCK_FLY_8_png
	this.instance_8 = new lib.Tween41("synched",0);
	this.instance_8.parent = this;
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween43("synched",0);
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},60).to({state:[{t:this.instance_9}]},5).to({state:[]},1).wait(170));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(60).to({_off:false},0).to({_off:true},5).wait(171));

	// DUCK_FLY_2_png
	this.instance_10 = new lib.Tween43("synched",0);
	this.instance_10.parent = this;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween41("synched",0);
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},55).to({state:[{t:this.instance_11}]},5).to({state:[]},1).wait(175));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(55).to({_off:false},0).to({_off:true},5).wait(176));

	// DUCK_FLY_6_png
	this.instance_12 = new lib.Tween45("synched",0);
	this.instance_12.parent = this;
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween43("synched",0);
	this.instance_13.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},50).to({state:[{t:this.instance_13}]},5).to({state:[]},1).wait(180));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(50).to({_off:false},0).to({_off:true},5).wait(181));

	// DUCK_FLY_3_png
	this.instance_14 = new lib.Tween47("synched",0);
	this.instance_14.parent = this;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween48("synched",0);
	this.instance_15.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},45).to({state:[{t:this.instance_15}]},5).to({state:[]},1).wait(185));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(45).to({_off:false},0).to({_off:true},5).wait(186));

	// DUCK_FLY_6_png
	this.instance_16 = new lib.Tween45("synched",0);
	this.instance_16.parent = this;
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween46("synched",0);
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},40).to({state:[{t:this.instance_17}]},5).to({state:[]},1).wait(190));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(40).to({_off:false},0).to({_off:true},5).wait(191));

	// DUCK_FLY_2_png
	this.instance_18 = new lib.Tween43("synched",0);
	this.instance_18.parent = this;
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween44("synched",0);
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},35).to({state:[{t:this.instance_19}]},5).to({state:[]},1).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(35).to({_off:false},0).to({_off:true},5).wait(196));

	// DUCK_FLY_8_png
	this.instance_20 = new lib.Tween41("synched",0);
	this.instance_20.parent = this;
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween42("synched",0);
	this.instance_21.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},30).to({state:[{t:this.instance_21}]},5).to({state:[]},1).wait(200));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(30).to({_off:false},0).to({_off:true},5).wait(201));

	// DUCK_FLY_2_png_copy
	this.instance_22 = new lib.Tween51("synched",0);
	this.instance_22.parent = this;
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween41("synched",0);
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},25).to({state:[{t:this.instance_23}]},5).to({state:[]},1).wait(205));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(25).to({_off:false},0).to({_off:true},5).wait(206));

	// DUCK_FLY_6_png
	this.instance_24 = new lib.Tween49("synched",0);
	this.instance_24.parent = this;
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween50("synched",0);
	this.instance_25.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_24}]},20).to({state:[{t:this.instance_25}]},5).to({state:[]},1).wait(210));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(20).to({_off:false},0).to({_off:true},5).wait(211));

	// DUCK_FLY_3_png
	this.instance_26 = new lib.Tween47("synched",0);
	this.instance_26.parent = this;
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween48("synched",0);
	this.instance_27.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},15).to({state:[{t:this.instance_27}]},5).to({state:[]},1).wait(215));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(15).to({_off:false},0).to({_off:true},5).wait(216));

	// DUCK_FLY_6_png
	this.instance_28 = new lib.Tween45("synched",0);
	this.instance_28.parent = this;
	this.instance_28._off = true;

	this.instance_29 = new lib.Tween46("synched",0);
	this.instance_29.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28}]},10).to({state:[{t:this.instance_29}]},5).to({state:[]},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(10).to({_off:false},0).to({_off:true},5).wait(221));

	// DUCK_FLY_2_png
	this.instance_30 = new lib.Tween43("synched",0);
	this.instance_30.parent = this;
	this.instance_30._off = true;

	this.instance_31 = new lib.Tween44("synched",0);
	this.instance_31.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30}]},5).to({state:[{t:this.instance_31}]},5).to({state:[]},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(5).to({_off:false},0).to({_off:true},5).wait(226));

	// DUCK_FLY_8_png
	this.instance_32 = new lib.Tween41("synched",0);
	this.instance_32.parent = this;

	this.instance_33 = new lib.Tween42("synched",0);
	this.instance_33.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).to({state:[{t:this.instance_33}]},5).to({state:[]},1).wait(230));
	this.timeline.addTween(cjs.Tween.get(this.instance_32).to({_off:true},5).wait(231));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500,-524.3,1000,1031.1999999999998);


// stage content:
(lib.AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRALARGE_Canvas_TEST2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhZCAjKMAAAhGTMCyFAAAMAAABGTg");
	mask.setTransform(570,225.025);

	// DUCK_11
	this.instance = new lib.DUCK4();
	this.instance.parent = this;
	this.instance.setTransform(1031.4,37.8,0.1781,0.1781);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2000));

	// DUCK_10
	this.instance_1 = new lib.DUCK3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(877.55,57.15,0.2035,0.2035);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2000));

	// DUCK_9
	this.instance_2 = new lib.DUCK2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(752.5,79.55,0.243,0.243);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2000));

	// DUCK_8
	this.instance_3 = new lib.DUCK1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(616.3,110.05,0.2358,0.2358);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2000));

	// DUCK_7
	this.instance_4 = new lib.DUCK4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(482.55,142.5,0.2584,0.2584,0,0,0,0.2,0.2);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2000));

	// DUCK_3
	this.instance_5 = new lib.DUCK3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(323.25,171.5,0.2522,0.2522);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(2000));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhZCAjKMAAAhGTMCyFAAAMAAABGTg");
	mask_1.setTransform(570,225.025);

	// DUCK_2
	this.instance_6 = new lib.DUCK2_OPTIMIZED();
	this.instance_6.parent = this;
	this.instance_6.setTransform(421.7,274.1,0.2944,0.2944);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(2000));

	// DUCK_4
	this.instance_7 = new lib.DUCK1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(630.4,310.45,0.3107,0.3107,0,0,0,0.3,0);

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2000));

	// DUCK_5
	this.instance_8 = new lib.DUCK3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(842.95,321.3,0.3323,0.3323);

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2000));

	// DUCK_6
	this.instance_9 = new lib.DUCK2();
	this.instance_9.parent = this;
	this.instance_9.setTransform(1054.1,347.65,0.3597,0.3597);

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(2000));

	// DUCK_1
	this.instance_10 = new lib.DUCK1OPTIMIZED();
	this.instance_10.parent = this;
	this.instance_10.setTransform(102.1,216.35,0.2558,0.2558);

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(2000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(570.1,225.1,569.9,224.9);
// library properties:
lib.properties = {
	id: '1F98D6041E154D57B6B76D7D1DF8F764',
	width: 1140,
	height: 450,
	fps: 24,
	color: "#0066CC",
	opacity: 0.00,
	manifest: [
		{src:"images/AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_.png?1562103623249", id:"AligmentFly_2A_OPTIMIZING_HTML5_1140PX_EXTRA_LARGE_Canvas_TEST_2_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1F98D6041E154D57B6B76D7D1DF8F764'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;