$(window).scroll(function() {
  if ($("#menu").offset().top > 380) {
    $("#menu").addClass("navbar-white");
    $("#logo").addClass("logoLst");
    $("#drawer").addClass("sidebar-heading-2");
    $("#drawer-logo").addClass("drawer-logo-2");
  } else {
    $("#menu").removeClass("navbar-white");
    $("#logo").removeClass("logoLst");
    $("#drawer").removeClass("sidebar-heading-2");
    $("#drawer-logo").removeClass("drawer-logo-2");
  }
});

$(".burger").click(function() {
  $(".burger").toggleClass("open");
});

$("#menu-toggle").click(function(e) {
  e.preventDefault();
  $("#wrapper").toggleClass("toggled");
});

$(".employee-section").mouseover(function() {
  $("#link-employee").toggleClass("d-lg-none animated bounceInLeft fast");
});

$(".employee-section").mouseout(function() {
  $("#link-employee").toggleClass("d-lg-none animated bounceInLeft fast");
});

$(".advisor-section").mouseover(function() {
  $("#link-advisor").toggleClass("d-lg-none animated bounceInRight fast");
});

$(".advisor-section").mouseout(function() {
  $("#link-advisor").toggleClass("d-lg-none animated bounceInRight fast");
});

$(".employer-section").mouseover(function() {
  $("#link-employer").toggleClass("d-lg-none animated bounceInRight fast");
});

$(".employer-section").mouseout(function() {
  $("#link-employer").toggleClass("d-lg-none animated bounceInRight fast");
});


/* index benefits section */

$("#benef-1").mouseover(function() {
  $("#benef-1").addClass("blanco");
  $("#franja-g-1").removeClass("azul");
  $("#franja-g-1").addClass("rojo");
  $("#benef-1-content").removeClass("benef-card-content");
  $("#benef-1-content").addClass("padi");
  document.getElementById("benef-1-content").innerHTML='';
  document.getElementById("benef-1-content").innerHTML='<h5>Cost Savings</h5>Move past expensive pre-packaged products, and benefit from technology-driven, cost-optimized solutions.';

});

$("#benef-1").mouseout(function() {
  $("#benef-1").removeClass("blanco");
  $("#franja-g-1").addClass("azul");
  $("#franja-g-1").removeClass("rojo");
  $("#benef-1-content").removeClass("padi");
  $("#benef-1-content").addClass("benef-card-content");
  document.getElementById("benef-1-content").innerHTML='';
  document.getElementById("benef-1-content").innerHTML='<div><img src="img/ping.png" alt="savings" /><span class="benef-card-text"> Cost Savings</span></div>'
});

$("#benef-2").mouseover(function() {
  $("#benef-2").addClass("blanco");
  $("#franja-g-2").removeClass("azul");
  $("#franja-g-2").addClass("rojo");  
  $("#benef-2-content").removeClass("benef-card-content");
  $("#benef-2-content").addClass("padi");
  document.getElementById("benef-2-content").innerHTML='';
  document.getElementById("benef-2-content").innerHTML='<h5>Cost Transparency</h5>With no hidden fees or sales agendas, your WellthCoach will guide employees to track and improve their wealth and wellness.';

});

$("#benef-2").mouseout(function() {
  $("#benef-2").removeClass("blanco");
  $("#franja-g-2").addClass("azul");
  $("#franja-g-2").removeClass("rojo");
  $("#benef-2-content").removeClass("padi");
  $("#benef-2-content").addClass("benef-card-content");
  document.getElementById("benef-2-content").innerHTML='';
  document.getElementById("benef-2-content").innerHTML='<div><img src="img/bluecorners.png" alt="Transparency" /><span class="benef-card-text">100% Transparency</span></div>'
});


$("#benef-3").mouseover(function() {
  $("#benef-3").addClass("blanco");
  $("#franja-g-3").removeClass("rojo");
  $("#franja-g-3").addClass("azul");
  $("#benef-3-content").removeClass("benef-card-content");
  $("#benef-3-content").addClass("padi");
  document.getElementById("benef-3-content").innerHTML='';
  document.getElementById("benef-3-content").innerHTML='<h5>Increased Participation</h5>When you offer cost optimized solutions and value-driven service, you give employees a reason to become participants.';

});

$("#benef-3").mouseout(function() {
  $("#benef-3").removeClass("blanco");
  $("#franja-g-3").addClass("rojo");
  $("#franja-g-3").removeClass("azul");
  $("#benef-3-content").removeClass("padi");
  $("#benef-3-content").addClass("benef-card-content");
  document.getElementById("benef-3-content").innerHTML='';
  document.getElementById("benef-3-content").innerHTML='<img src="img/cup.png" alt="Guaranteed" />  <div class="benef-card-text text-center"> Increased <br /> Participation </div>'
});

$("#benef-4").mouseover(function() {
  $("#benef-4").addClass("blanco");
  $("#franja-g-4").removeClass("rojo");
  $("#franja-g-4").addClass("azul");
  $("#benef-4-content").removeClass("benef-card-content");
  $("#benef-4-content").addClass("padi");
  document.getElementById("benef-4-content").innerHTML='';
  document.getElementById("benef-4-content").innerHTML='<h5>Wealthier and Healthier Employees </h5>The WellthApp finally gives participants a single dashboard to track and improve their financial wealth and lifestyle wellness.';

});

$("#benef-4").mouseout(function() {
  $("#benef-4").removeClass("blanco");
  $("#franja-g-4").addClass("rojo");
  $("#franja-g-4").removeClass("azul");
  $("#benef-4-content").removeClass("padi");
  $("#benef-4-content").addClass("benef-card-content");
  document.getElementById("benef-4-content").innerHTML='';
  document.getElementById("benef-4-content").innerHTML='<img src="img/wallet.png" alt="Healthier" /> <div class="benef-card-text text-center"> Wealthier and <br /> Healthier Employees </div>'
});


/**empowered**/
/*
$("#moneyBox").mouseover(function() {
  document.getElementById("circleMoneyBox").setAttribute("style", "fill:#333554;");
  
});

$("#moneyBox").mouseout(function() {
  document.getElementById("circleMoneyBox").setAttribute("style", "fill:#0098fe;");
});
*/